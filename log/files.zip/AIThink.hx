package ai;

import model.Player;
import model.Camp;
import model.DamageType;
import GameEngine;
import TurnManager;
import model.Buff;

/**
 * AI 思考模块 - 启发式评估 + 可进化权重
 *
 * 设计要点：
 * - AIThink 可以**实例化**，每个实例有独立权重（用于进化对比）
 * - 保留静态 `default` 实例作为默认 AI
 * - 权重通过 WeightSet 结构体管理，方便序列化和对比
 * - 评估函数完全基于结构化数据，不依赖文字日志解析
 */
class AIThink {

    // ─────────────────────────────────────────────────────────────
    // 默认权重常量（作为基准参考）
    // ─────────────────────────────────────────────────────────────
    public static var DEFAULT_WEIGHTS:WeightSet = {
        damage:       3.0,
        heal:         2.0,
        shield:       1.5,
        poison:       1.2,
        doubleStar:  50.0,
        zeroCombo:   25.0,
        sixCombo:    15.0,
        zeroRisk:   -40.0,
        zeroCountdown: -30.0,
        oppZeroGood: 20.0,
        hpAdvantage:  0.5,
        handQuality:  2.0,
        // 角色特化权重
        mageZeroBonus:    15.0,  // 法师0组合加成
        wukongZeroTwoBonus: 30.0, // 悟空[0,2]加成
        ninjaAttackBonus:  8.0,  // 忍者持续攻击加成（触发毒+法伤被动）
        zhangfeiHealBonus: 10.0, // 张飞[0,4/6]回血加成（积累怒气）
        xiaoqiaoHealBonus: 15.0, // 小乔回血加成（回血×1.5）
        zangshiCakeThreshold: 6.0, // 藏师蛋糕数量达到此值时开始使用
        // 张飞模态偏好（0=无偏好，正值=偏好该模态）
        zhangfeiModal1Pref: 5.0,
        zhangfeiModal3Pref: 3.0,
    };

    // ─────────────────────────────────────────────────────────────
    // 实例权重（默认复制 DEFAULT_WEIGHTS）
    // ─────────────────────────────────────────────────────────────
    public var weights:WeightSet;

    // Elo 评分（用于进化排名）
    public var elo:Float = 1200.0;

    // 标识符（用于日志）
    public var id:String;

    public function new(?id:String, ?weights:WeightSet) {
        this.id = (id != null) ? id : "AI_" + Std.string(Std.random(9999));
        this.weights = (weights != null) ? weights : copyWeights(DEFAULT_WEIGHTS);
    }

    // ─────────────────────────────────────────────────────────────
    // 权重工具方法
    // ─────────────────────────────────────────────────────────────

    public static function copyWeights(w:WeightSet):WeightSet {
        return {
            damage: w.damage, heal: w.heal, shield: w.shield, poison: w.poison,
            doubleStar: w.doubleStar, zeroCombo: w.zeroCombo, sixCombo: w.sixCombo,
            zeroRisk: w.zeroRisk, zeroCountdown: w.zeroCountdown, oppZeroGood: w.oppZeroGood,
            hpAdvantage: w.hpAdvantage, handQuality: w.handQuality,
            mageZeroBonus: w.mageZeroBonus, wukongZeroTwoBonus: w.wukongZeroTwoBonus,
            ninjaAttackBonus: w.ninjaAttackBonus, zhangfeiHealBonus: w.zhangfeiHealBonus,
            xiaoqiaoHealBonus: w.xiaoqiaoHealBonus, zangshiCakeThreshold: w.zangshiCakeThreshold,
            zhangfeiModal1Pref: w.zhangfeiModal1Pref, zhangfeiModal3Pref: w.zhangfeiModal3Pref,
        };
    }

    /**
     * 对权重施加随机扰动，生成"挑战者"权重
     * @param magnitude 扰动幅度（0.1 = 10%随机变动）
     */
    public static function mutateWeights(base:WeightSet, magnitude:Float = 0.15):WeightSet {
        function perturb(v:Float):Float {
            var noise = (Math.random() * 2 - 1) * magnitude;
            // 保持符号（负权重不能变正）
            var result = v * (1.0 + noise);
            if (v < 0 && result > 0) return v * 0.5;
            if (v > 0 && result < 0) return v * 0.5;
            return result;
        }
        return {
            damage: perturb(base.damage), heal: perturb(base.heal),
            shield: perturb(base.shield), poison: perturb(base.poison),
            doubleStar: perturb(base.doubleStar), zeroCombo: perturb(base.zeroCombo),
            sixCombo: perturb(base.sixCombo), zeroRisk: perturb(base.zeroRisk),
            zeroCountdown: perturb(base.zeroCountdown), oppZeroGood: perturb(base.oppZeroGood),
            hpAdvantage: perturb(base.hpAdvantage), handQuality: perturb(base.handQuality),
            mageZeroBonus: perturb(base.mageZeroBonus),
            wukongZeroTwoBonus: perturb(base.wukongZeroTwoBonus),
            ninjaAttackBonus: perturb(base.ninjaAttackBonus),
            zhangfeiHealBonus: perturb(base.zhangfeiHealBonus),
            xiaoqiaoHealBonus: perturb(base.xiaoqiaoHealBonus),
            zangshiCakeThreshold: Math.max(3, perturb(base.zangshiCakeThreshold)),
            zhangfeiModal1Pref: perturb(base.zhangfeiModal1Pref),
            zhangfeiModal3Pref: perturb(base.zhangfeiModal3Pref),
        };
    }

    // ─────────────────────────────────────────────────────────────
    // 兼容旧静态接口（供 BattleLearning 和外部调用）
    // ─────────────────────────────────────────────────────────────
    static var _defaultInstance:AIThink = new AIThink("default");

    public static function getWeight(name:String):Float {
        return getWeightFrom(_defaultInstance.weights, name);
    }

    public static function setWeight(name:String, value:Float):Void {
        setWeightOn(_defaultInstance.weights, name, value);
    }

    public static function getAllWeights():Map<String, Float> {
        return weightsToMap(_defaultInstance.weights);
    }

    // ─────────────────────────────────────────────────────────────
    // 核心：选择最佳行动（实例方法）
    // ─────────────────────────────────────────────────────────────

    public function chooseActionWith(actor:Player, opponent:Player, engine:GameEngine):{myHand:Int, targetHand:Int} {
        var candidates:Array<CandidateMove> = [];

        for (myHandIdx in 0...2) {
            for (targetHandIdx in 0...2) {
                if (opponent.hands[targetHandIdx] == 0) continue;
                if (!actor.isValidTouch(myHandIdx, opponent, targetHandIdx)) continue;

                var score = evaluateMoveWith(actor, opponent, myHandIdx, targetHandIdx, engine);
                candidates.push({ myHandIdx: myHandIdx, targetHandIdx: targetHandIdx, score: score });
            }
        }

        if (candidates.length == 0) return null;
        candidates.sort(function(a, b) return Std.int(b.score - a.score));

        // Top-3 随机选（避免过于机械）
        var topCount = Std.int(Math.min(3, candidates.length));
        var chosen = candidates[Std.random(topCount)];

        trace('🧠 [${id}] ${actor.name} 选择：手${chosen.myHandIdx}→对手手${chosen.targetHandIdx}，分数${Std.int(chosen.score)}');
        return { myHand: chosen.myHandIdx, targetHand: chosen.targetHandIdx };
    }

    public function evaluateMoveWith(actor:Player, opponent:Player, myHandIdx:Int, targetHandIdx:Int, engine:GameEngine):Float {
        var w = this.weights;
        var score:Float = 0;
        var oldValue = actor.hands[myHandIdx];
        var newValue = (oldValue + opponent.hands[targetHandIdx]) % 10;

        score += estimateImmediateBenefit(actor, opponent, myHandIdx, oldValue, newValue, w);
        score += evaluateComboPotential(actor, newValue, myHandIdx, w);
        score += evaluateRisk(actor, myHandIdx, newValue, w);
        score += evaluateOpponentThreat(actor, opponent, w);
        score += evaluateCharacterSpecific(actor, opponent, myHandIdx, newValue, w, engine);

        return score;
    }

    // ─────────────────────────────────────────────────────────────
    // 静态快捷接口（给 AIBattleRunner 的简单调用）
    // ─────────────────────────────────────────────────────────────
    public static function chooseAction(actor:Player, opponent:Player, engine:GameEngine):{myHand:Int, targetHand:Int} {
        return _defaultInstance.chooseActionWith(actor, opponent, engine);
    }

    // ─────────────────────────────────────────────────────────────
    // 评估函数（接受权重参数，无副作用，易于测试）
    // ─────────────────────────────────────────────────────────────

    private static function estimateImmediateBenefit(actor:Player, opponent:Player, handIdx:Int, oldValue:Int, newValue:Int, w:WeightSet):Float {
        var score:Float = 0;
        var simHands = actor.hands.copy();
        simHands[handIdx] = newValue;

        // [x,6] 触发 → 回血30
        if (newValue == 6 && oldValue != 6) {
            score += 30 * w.heal;
        }

        // 0组合收益估算
        if (simHands[0] == 0 || simHands[1] == 0) {
            var otherVal = (simHands[0] == 0) ? simHands[1] : simHands[0];
            score += evaluateZeroComboValue(otherVal, w);
        }

        // 双子星收益
        if (simHands[0] == simHands[1]) {
            score += estimateDoubleStarValue(simHands[0], w);
        }

        return score;
    }

    private static function evaluateZeroComboValue(otherValue:Int, w:WeightSet):Float {
        switch (otherValue) {
            case 0:    return 150 * w.damage;
            case 1,5,8,9: return 40 * w.damage;
            case 2,3:  return 20 * w.shield;
            case 4,6:  return 30 * w.heal;
            case 7:    return 10 * w.damage + 10 * w.poison;
        }
        return 0;
    }

    private static function estimateDoubleStarValue(num:Int, w:WeightSet):Float {
        // 双子星各有不同价值，做粗略估算
        switch (num) {
            case 9: return 200 * w.damage; // [9,9] 超级伤害
            case 0: return 150 * w.damage; // [0,0] 真伤
            case 7: return 30 * w.damage + 30 * w.poison;
            case 6: return 90 * w.heal;
            case 8: return 60 * w.damage;  // 额外行动
            case 1: return 50;             // 无敌（防御价值难量化）
            case 4: return 40 * w.damage;  // 翻倍
            case 5: return 30;             // 反弹
            case 2,3: return 30 * w.shield;
        }
        return w.doubleStar;
    }

    private static function evaluateComboPotential(actor:Player, newValue:Int, handIdx:Int, w:WeightSet):Float {
        var score:Float = 0;
        var otherValue = actor.hands[1 - handIdx];

        // 双子星潜力
        if (newValue == otherValue) score += w.doubleStar;
        else if (newValue != 0 && (Math.abs(newValue - otherValue) == 1 || Math.abs(newValue - otherValue) == 9)) {
            score += 10; // 差1就能凑
        }

        // 0组合潜力
        if (newValue == 0) score += w.zeroCombo;

        // [x,6] 潜力
        if (otherValue == 6 || newValue == 6) score += w.sixCombo;

        return score;
    }

    private static function evaluateRisk(actor:Player, handIdx:Int, newValue:Int, w:WeightSet):Float {
        var score:Float = 0;

        if (newValue == 0) {
            var currentTurns = (handIdx == 0) ? actor.zeroTurns0 : actor.zeroTurns1;
            // 另一只手也是0 → 双0死亡危机！惩罚极大
            var otherHand = actor.hands[1 - handIdx];
            if (otherHand == 0) {
                score += w.zeroRisk * 5; // 极度危险
            } else if (currentTurns <= 0) {
                score += w.zeroRisk * 1.5;
            } else {
                score += w.zeroRisk;
            }
        }

        // 已有0且倒计时快用完
        var otherIdx = 1 - handIdx;
        if (actor.hands[otherIdx] == 0) {
            var otherTurns = (otherIdx == 0) ? actor.zeroTurns0 : actor.zeroTurns1;
            if (otherTurns <= 1) score += w.zeroCountdown;
        }

        return score;
    }

    private static function evaluateOpponentThreat(actor:Player, opponent:Player, w:WeightSet):Float {
        var score:Float = 0;

        if (opponent.hands[0] == 0 && opponent.hands[1] == 0) score += 30;
        if (opponent.hands[0] == 0 && opponent.zeroTurns0 <= 1) score += w.oppZeroGood * 0.5;
        if (opponent.hands[1] == 0 && opponent.zeroTurns1 <= 1) score += w.oppZeroGood * 0.5;

        var hpDiff = actor.hp - opponent.hp;
        score += hpDiff * w.hpAdvantage;

        return score;
    }

    private static function evaluateCharacterSpecific(
        actor:Player, opponent:Player, myHandIdx:Int, newValue:Int,
        w:WeightSet, engine:GameEngine
    ):Float {
        var score:Float = 0;
        var name = actor.name;
        var otherIdx = 1 - myHandIdx;
        var otherVal = actor.hands[otherIdx];

        // ── 法师：0组合有翻倍+45法伤额外加成 ──
        if (name == "法师" || name == "fashi") {
            if (newValue == 0) score += w.mageZeroBonus;
        }

        // ── 孙悟空：[0,2]大招价值高 ──
        if (name == "孙悟空" || name == "sunwukong") {
            if ((newValue == 0 && otherVal == 2) || (newValue == 2 && otherVal == 0)) {
                score += w.wukongZeroTwoBonus; // 70法伤+回70+冻结
            }
            // 孙悟空打物伤会叠加x值，优先打人
            if (newValue != 0 && newValue != 2) score += 5;
        }

        // ── 忍者：打物伤就附加50%法伤+加毒，核心收益来自持续攻击 ──
        if (name == "忍者" || name == "renzhe") {
            // 只要打物伤就加分（不管打出多少），因为被动技能已经算好了
            if (newValue != 0) {
                // 检查敌方毒层越多忍者减伤越高，此时更安全，可以激进
                var poisonBuff = opponent.getBuff("POISON");
                var poisonLayers = (poisonBuff != null) ? poisonBuff.layers : 0;
                score += w.ninjaAttackBonus + poisonLayers * 3.0;
            }
        }

        // ── 张飞：模态③和[0,4/6]回血能积累怒气 ──
        if (name == "张飞" || name == "zhangfei") {
            if (newValue == 4 || newValue == 6) score += w.zhangfeiHealBonus;
            // 检查是否接近狂暴（24怒气）
            var zf = Std.isOfType(actor, character.ZhangFei) ? (cast actor : character.ZhangFei) : null;
            if (zf != null) {
                if (zf.rage >= 20) score += 20; // 接近狂暴时激进
                if (zf.isFrenzied()) score += 15; // 狂暴中优先打伤害
                // 模态偏好
                if (zf.modal == 1) score += w.zhangfeiModal1Pref;
                if (zf.modal == 3 && newValue != 0) score += w.zhangfeiModal3Pref;
            }
        }

        // ── 小乔：[x,6]和[0,4]回血×1.5有额外价值 ──
        if (name == "小乔" || name == "xiaoqiao") {
            if (newValue == 6) score += w.xiaoqiaoHealBonus;
            if (newValue == 4) score += w.xiaoqiaoHealBonus * 0.5;
        }

        // ── 藏师：蛋糕够了就要用（由handleAction处理，这里只给提示分） ──
        if (name == "藏师" || name == "zangshi") {
            var zs = Std.isOfType(actor, character.ZangShi) ? (cast actor : character.ZangShi) : null;
            if (zs != null && zs.cakes >= Std.int(w.zangshiCakeThreshold)) {
                // 蛋糕够了，优先防守（回血）等用蛋糕
                if (newValue == 4 || newValue == 6) score += 8;
            }
        }

        // ── 大乔：打物伤可回血，优先打人 ──
        if (name == "大乔" || name == "daqiao") {
            if (newValue != 0) score += 8;
            // 接近进化（HP>250）时更激进
            if (actor.hp > 250 && !Std.isOfType(actor, character.DaQiao)) score += 15;
        }

        return score;
    }

    // ─────────────────────────────────────────────────────────────
    // 权重 Map 互转工具（供 tune_weights.py 接口用）
    // ─────────────────────────────────────────────────────────────
    public static function weightsToMap(w:WeightSet):Map<String, Float> {
        var m = new Map<String, Float>();
        m.set("damage", w.damage); m.set("heal", w.heal);
        m.set("shield", w.shield); m.set("poison", w.poison);
        m.set("doubleStar", w.doubleStar); m.set("zeroCombo", w.zeroCombo);
        m.set("sixCombo", w.sixCombo); m.set("zeroRisk", w.zeroRisk);
        m.set("zeroCountdown", w.zeroCountdown); m.set("oppZeroGood", w.oppZeroGood);
        m.set("hpAdvantage", w.hpAdvantage); m.set("handQuality", w.handQuality);
        m.set("mageZeroBonus", w.mageZeroBonus); m.set("wukongZeroTwoBonus", w.wukongZeroTwoBonus);
        m.set("ninjaAttackBonus", w.ninjaAttackBonus); m.set("zhangfeiHealBonus", w.zhangfeiHealBonus);
        m.set("xiaoqiaoHealBonus", w.xiaoqiaoHealBonus);
        return m;
    }

    public static function getWeightFrom(w:WeightSet, name:String):Float {
        switch (name) {
            case "damage": return w.damage; case "heal": return w.heal;
            case "shield": return w.shield; case "poison": return w.poison;
            case "doubleStar": return w.doubleStar; case "zeroCombo": return w.zeroCombo;
            case "sixCombo": return w.sixCombo; case "zeroRisk": return w.zeroRisk;
            case "zeroCountdown": return w.zeroCountdown; case "oppZeroGood": return w.oppZeroGood;
            case "hpAdvantage": return w.hpAdvantage; case "handQuality": return w.handQuality;
            case "mageZeroBonus": return w.mageZeroBonus; case "wukongZeroTwoBonus": return w.wukongZeroTwoBonus;
            case "ninjaAttackBonus": return w.ninjaAttackBonus; case "zhangfeiHealBonus": return w.zhangfeiHealBonus;
            case "xiaoqiaoHealBonus": return w.xiaoqiaoHealBonus;
        }
        return 0.0;
    }

    public static function setWeightOn(w:WeightSet, name:String, value:Float):Void {
        switch (name) {
            case "damage": w.damage = value; case "heal": w.heal = value;
            case "shield": w.shield = value; case "poison": w.poison = value;
            case "doubleStar": w.doubleStar = value; case "zeroCombo": w.zeroCombo = value;
            case "sixCombo": w.sixCombo = value; case "zeroRisk": w.zeroRisk = value;
            case "zeroCountdown": w.zeroCountdown = value; case "oppZeroGood": w.oppZeroGood = value;
            case "hpAdvantage": w.hpAdvantage = value; case "handQuality": w.handQuality = value;
            case "mageZeroBonus": w.mageZeroBonus = value; case "wukongZeroTwoBonus": w.wukongZeroTwoBonus = value;
            case "ninjaAttackBonus": w.ninjaAttackBonus = value; case "zhangfeiHealBonus": w.zhangfeiHealBonus = value;
            case "xiaoqiaoHealBonus": w.xiaoqiaoHealBonus = value;
        }
    }
}

typedef WeightSet = {
    var damage:Float;
    var heal:Float;
    var shield:Float;
    var poison:Float;
    var doubleStar:Float;
    var zeroCombo:Float;
    var sixCombo:Float;
    var zeroRisk:Float;
    var zeroCountdown:Float;
    var oppZeroGood:Float;
    var hpAdvantage:Float;
    var handQuality:Float;
    var mageZeroBonus:Float;
    var wukongZeroTwoBonus:Float;
    var ninjaAttackBonus:Float;
    var zhangfeiHealBonus:Float;
    var xiaoqiaoHealBonus:Float;
    var zangshiCakeThreshold:Float;
    var zhangfeiModal1Pref:Float;
    var zhangfeiModal3Pref:Float;
}

typedef CandidateMove = {
    var myHandIdx:Int;
    var targetHandIdx:Int;
    var score:Float;
}
